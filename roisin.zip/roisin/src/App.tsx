// Use the existing image in `src/Assets` to avoid missing file errors
import logo from "./Assets/headshot.jpg";
import "./index.css";


export default function App() {
  return (
    <>
      <header className="header">
        <nav className="navbar">
          <a className="brand" href="#hero">Roisin</a>
          <ul className="nav-links">
            <li><a href="#about">About</a></li>
            <li><a href="#projects">Projects</a></li>
            <li><a href="#exhibitions">Exhibitions</a></li>
            <li><a href="#contact">Contact</a></li>
          </ul>
        </nav>
      </header>

      <main className="container">
        <section id="hero" className="section hero">
          <img src={logo} alt="headshot" className="hero-logo" />
          <h1>Roisin Mohally</h1>
          <p>Hello!</p>
        </section>

        <section id="about" className="section">
          <h2>About</h2>
          <p>This site shows my projects and how to reach me.</p>
        </section>

        <section id="projects" className="section projects">
          <h2>Projects</h2>
          <div className="projects-grid">
            <article className="card"><h3>Project One</h3><p>Coming soon.</p></article>
            <article className="card"><h3>Project Two</h3><p>Coming soon.</p></article>
            <article className="card"><h3>Project Three</h3><p>Coming soon.</p></article>
          </div>
        </section>

<section id="exhibitions" className="section exhibitions">
          <h2>Exhibitions</h2>
          <div className="exhibitions-grid">
            <article className="card"><h3>Exhibition One</h3><p>Coming soon.</p></article>
            <article className="card"><h3>Exhibition Two</h3><p>Coming soon.</p></article>
            <article className="card"><h3>Exhibition Three</h3><p>Coming soon.</p></article>
          </div>
        </section>


        <section id="contact" className="section contact">
          <h2>Contact</h2>
          <p>Email: <a href="mailto:roisinmohally66@gmail.com">roisinmohally66@gmail.com</a></p>
          <p>LinkedIn: <a href="https://insertlinkedinhere.com" target="_blank" rel="noopener noreferrer">Roisin Mohally</a></p>
        </section>
      </main>

      <footer className="footer">
        <p>&copy; {new Date().getFullYear()} Roisin Mohally. All rights reserved.</p>
      </footer>
    </>
  );
}
